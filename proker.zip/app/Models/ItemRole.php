<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ItemRole extends Model
{
    protected $fillable = [
        'name',
    ];
}
