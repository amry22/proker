<?php

namespace App\Filament\Resources\DataDepartmentResource\Pages;

use App\Filament\Resources\DataDepartmentResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateDataDepartment extends CreateRecord
{
    protected static string $resource = DataDepartmentResource::class;
}
